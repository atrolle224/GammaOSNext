ui_print "- Daijishou: RG477M emulator players"
sh "$MODPATH/apply.sh" 2>&1 | while IFS= read -r l; do ui_print "  $l"; done
touch "$MODPATH/remove"
ui_print "- This module removes itself on reboot."
