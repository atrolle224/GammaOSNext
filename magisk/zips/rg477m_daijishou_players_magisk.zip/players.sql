BEGIN;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'dreamcast.rg477m.flycast', player, 'dreamcast - Flycast 477M', 'Flycast 477M (com.flycast.emulator.rg477m): both controllers as player 1, Vulkan.', replace(am_start_arguments, '-n com.flycast.emulator/', '-n com.flycast.emulator.rg477m/'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.com.flycast.emulator')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast')
WHERE shortname = 'dreamcast' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'psp.rg477m.ppsspp', player, 'psp - PPSSPP 477M', 'PPSSPP 477M (org.ppsspp.ppsspp.rg477m): 3x rendering on the 477M.', replace(am_start_arguments, '-n org.ppsspp.ppsspp/.PpssppActivity', '-n org.ppsspp.ppsspp.rg477m/org.ppsspp.ppsspp.PpssppActivity'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.org.ppsspp.ppsspp')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp')
WHERE shortname = 'psp' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'n64.rg477m.m64plusfz', player, 'n64 - M64Plus FZ 477M', 'M64Plus FZ 477M (org.mupen64plusae.v3.fzurita.rg477m).', replace(am_start_arguments, '-n org.mupen64plusae.v3.fzurita/', '-n org.mupen64plusae.v3.fzurita.rg477m/'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.org.mupen64plusae.v3.fzurita')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz')
WHERE shortname = 'n64' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'nds.rg477m.melonds', player, 'nds - melonDS 477M', 'melonDS 477M (me.magnum.melonds.rg477m): OpenGL 2x, sticks on every controller.', replace(replace(am_start_arguments, 'me.magnum.melonds.LAUNCH_ROM', 'me.magnum.melonds.rg477m.LAUNCH_ROM'), 'me.magnum.melonds/.ui', 'me.magnum.melonds.rg477m/me.magnum.melonds.ui'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.me.magnum.melonds')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds')
WHERE shortname = 'nds' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'psx.rg477m.swanstation', player, 'psx - SwanStation 477M', 'RetroArch 477M with SwanStation, tuned for the 477M (4x = the panel''s 1280x960, Vulkan).', replace(am_start_arguments, 'com.retroarch.aarch64', 'com.retroarch.rg477m'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.ra64.swanstation')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation')
WHERE shortname = 'psx' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation') IS NOT NULL;
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m')
WHERE shortname = 'gc' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m') IS NOT NULL;
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod')
WHERE shortname = 'ps2' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod') IS NOT NULL;
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug')
WHERE shortname = 'xbox' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gb.rg477m.ra.gambatte', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gb - RetroArch 477M (gambatte)', 'RetroArch 477M with gambatte: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO gambatte
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:dmg|gb|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.gambatte');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.gambatte'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.gambatte')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.gambatte')
WHERE shortname = 'gb' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.gambatte') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gb.rg477m.ra.sameboy', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gb - RetroArch 477M (sameboy)', 'RetroArch 477M with sameboy: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO sameboy
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:gb|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.sameboy');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.sameboy'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.sameboy')) END
WHERE shortname = 'gb' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.sameboy') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gb.rg477m.ra.mgba', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gb - RetroArch 477M (mgba)', 'RetroArch 477M with mgba: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO mgba
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:dmg|gb|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.mgba');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.mgba'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.mgba')) END
WHERE shortname = 'gb' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gb.rg477m.ra.mgba') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gbc.rg477m.ra.gambatte', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gbc - RetroArch 477M (gambatte)', 'RetroArch 477M with gambatte: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO gambatte
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:dmg|gb|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.gambatte');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.gambatte'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.gambatte')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.gambatte')
WHERE shortname = 'gbc' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.gambatte') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gbc.rg477m.ra.sameboy', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gbc - RetroArch 477M (sameboy)', 'RetroArch 477M with sameboy: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO sameboy
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:gb|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.sameboy');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.sameboy'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.sameboy')) END
WHERE shortname = 'gbc' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.sameboy') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gbc.rg477m.ra.mgba', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gbc - RetroArch 477M (mgba)', 'RetroArch 477M with mgba: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO mgba
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:gb|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.mgba');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.mgba'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.mgba')) END
WHERE shortname = 'gbc' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gbc.rg477m.ra.mgba') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gba.rg477m.ra.mgba', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gba - RetroArch 477M (mgba)', 'RetroArch 477M with mgba: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO mgba
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:gb|gba|gbc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.mgba');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.mgba'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.mgba')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.mgba')
WHERE shortname = 'gba' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.mgba') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gba.rg477m.ra.gpsp', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gba - RetroArch 477M (gpsp)', 'RetroArch 477M with gpsp: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO gpsp
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:bin|gba|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.gpsp');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.gpsp'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.gpsp')) END
WHERE shortname = 'gba' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.gpsp') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gba.rg477m.ra.vbam', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gba - RetroArch 477M (vbam)', 'RetroArch 477M with vbam: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO vbam
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:cgb|dmg|gb|gba|gbc|sgb|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.vbam');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.vbam'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.vbam')) END
WHERE shortname = 'gba' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gba.rg477m.ra.vbam') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'snes.rg477m.ra.snes9x', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'snes - RetroArch 477M (snes9x)', 'RetroArch 477M with snes9x: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO snes9x
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:bs|fig|sfc|smc|st|swc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x')
WHERE shortname = 'snes' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'snes.rg477m.ra.bsnes', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'snes - RetroArch 477M (bsnes)', 'RetroArch 477M with bsnes: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO bsnes
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:gb|gbc|sfc|smc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.bsnes');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.bsnes'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.bsnes')) END
WHERE shortname = 'snes' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.bsnes') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'snes.rg477m.ra.snes9x2010', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'snes - RetroArch 477M (snes9x2010)', 'RetroArch 477M with snes9x2010: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO snes9x2010
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:bsx|dx2|fig|gd3|gd7|sfc|smc|swc|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x2010');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x2010'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x2010')) END
WHERE shortname = 'snes' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'snes.rg477m.ra.snes9x2010') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'segacd.rg477m.ra.genesis_plus_gx', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'segacd - RetroArch 477M (genesis_plus_gx)', 'RetroArch 477M with genesis_plus_gx: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO genesis_plus_gx
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:chd|cue|iso|m3u|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.genesis_plus_gx');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.genesis_plus_gx'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.genesis_plus_gx')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.genesis_plus_gx')
WHERE shortname = 'segacd' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.genesis_plus_gx') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'segacd.rg477m.ra.picodrive', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'segacd - RetroArch 477M (picodrive)', 'RetroArch 477M with picodrive: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO picodrive
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:chd|cue|iso|m3u|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.picodrive');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.picodrive'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.picodrive')) END
WHERE shortname = 'segacd' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'segacd.rg477m.ra.picodrive') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'genesis.rg477m.ra.genesis_plus_gx', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'genesis - RetroArch 477M (genesis_plus_gx)', 'RetroArch 477M with genesis_plus_gx: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO genesis_plus_gx
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:68k|bin|chd|cue|gen|gg|iso|md|mdx|sg|smd|sms|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.genesis_plus_gx');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.genesis_plus_gx'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.genesis_plus_gx')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.genesis_plus_gx')
WHERE shortname = 'genesis' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.genesis_plus_gx') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'genesis.rg477m.ra.picodrive', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'genesis - RetroArch 477M (picodrive)', 'RetroArch 477M with picodrive: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO picodrive
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:32x|68k|bin|chd|cue|gen|gg|iso|m3u|md|pco|sgd|smd|sms|7z|zip)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.picodrive');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.picodrive'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.picodrive')) END
WHERE shortname = 'genesis' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'genesis.rg477m.ra.picodrive') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'master.rg477m.ra.genesis_plus_gx', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'master - RetroArch 477M (genesis_plus_gx)', 'RetroArch 477M with genesis_plus_gx: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO genesis_plus_gx
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:68k|bin|chd|cue|gen|gg|iso|md|mdx|sg|smd|sms|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.genesis_plus_gx');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.genesis_plus_gx'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.genesis_plus_gx')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.genesis_plus_gx')
WHERE shortname = 'master' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.genesis_plus_gx') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'master.rg477m.ra.gearsystem', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'master - RetroArch 477M (gearsystem)', 'RetroArch 477M with gearsystem: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO gearsystem
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:sms|gg|sg|bin|rom|7z|zip)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.gearsystem');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.gearsystem'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.gearsystem')) END
WHERE shortname = 'master' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.gearsystem') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'master.rg477m.ra.picodrive', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'master - RetroArch 477M (picodrive)', 'RetroArch 477M with picodrive: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO picodrive
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:32x|68k|bin|chd|cue|gen|gg|iso|m3u|md|pco|sgd|smd|sms|7z|zip)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.picodrive');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.picodrive'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.picodrive')) END
WHERE shortname = 'master' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'master.rg477m.ra.picodrive') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gamegear.rg477m.ra.genesis_plus_gx', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gamegear - RetroArch 477M (genesis_plus_gx)', 'RetroArch 477M with genesis_plus_gx: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO genesis_plus_gx
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:68k|bin|chd|cue|gen|gg|iso|md|mdx|sg|smd|sms|zip|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.genesis_plus_gx');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.genesis_plus_gx'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.genesis_plus_gx')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.genesis_plus_gx')
WHERE shortname = 'gamegear' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.genesis_plus_gx') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'gamegear.rg477m.ra.gearsystem', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'gamegear - RetroArch 477M (gearsystem)', 'RetroArch 477M with gearsystem: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO gearsystem
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:sms|gg|sg|bin|rom|7z|zip)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.gearsystem');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.gearsystem'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.gearsystem')) END
WHERE shortname = 'gamegear' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gamegear.rg477m.ra.gearsystem') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'ngpc.rg477m.ra.mednafen_ngp', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'ngpc - RetroArch 477M (mednafen_ngp)', 'RetroArch 477M with mednafen_ngp: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO mednafen_ngp
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:zip|ngp|ngc|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.mednafen_ngp');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.mednafen_ngp'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.mednafen_ngp')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.mednafen_ngp')
WHERE shortname = 'ngpc' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.mednafen_ngp') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'ngpc.rg477m.ra.race', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'ngpc - RetroArch 477M (race)', 'RetroArch 477M with race: RetroAchievements on, controllers profiled for the 477M.', '-n com.retroarch.rg477m/com.retroarch.browser.retroactivity.RetroActivityFuture
 -e ROM {file.path}
 -e LIBRETRO race
 -e CONFIGFILE /storage/emulated/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg', 1, 0, '^(.*)\.(?:zip|ngp|ngc|7z)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.race');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.race'))
   THEN player_id_list
   ELSE json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.race')) END
WHERE shortname = 'ngpc' AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ngpc.rg477m.ra.race') IS NOT NULL;

-- Saturn: Yaba Sanshiro 2 (apply.sh makes the installed one the default)
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'saturn.org.devmiyax.yabasanshioro2.pro', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'saturn - YabaSanshiro 2 Pro', 'Standalone Yaba Sanshiro 2: the maintained Saturn emulator for Android.', '-n org.devmiyax.yabasanshioro2.pro/org.uoyabause.android.Yabause
 -a android.intent.action.MAIN
 -e org.uoyabause.android.FileNameUri {file.uri}
 --activity-clear-task
 --activity-clear-top
 --activity-no-history', 0, 1, '^(.*)\.(?:bin|ccd|chd|cue|iso|m3u|mds|toc|zip)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'saturn.org.devmiyax.yabasanshioro2.pro');
UPDATE PlatformEntity SET player_id_list = json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'saturn.org.devmiyax.yabasanshioro2.pro'))
WHERE shortname = 'saturn' AND NOT EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'saturn.org.devmiyax.yabasanshioro2.pro'));
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'saturn.org.devmiyax.yabasanshioro2', (SELECT player FROM PlayerEntity WHERE id = COALESCE((SELECT MIN(id) FROM PlayerEntity WHERE am_start_arguments LIKE '%com.retroarch%'), (SELECT MIN(id) FROM PlayerEntity))), 'saturn - YabaSanshiro 2', 'Standalone Yaba Sanshiro 2: the maintained Saturn emulator for Android.', '-n org.devmiyax.yabasanshioro2/org.uoyabause.android.Yabause
 -a android.intent.action.VIEW
 -e org.uoyabause.android.FileNameUri {file.path}
 --activity-clear-task
 --activity-clear-top
 --activity-no-history', 0, 1, '^(.*)\.(?:bin|ccd|chd|cue|iso|m3u|mds|toc|zip)$', ''
WHERE NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'saturn.org.devmiyax.yabasanshioro2');
UPDATE PlatformEntity SET player_id_list = json_insert(COALESCE(NULLIF(player_id_list, ''), '[]'), '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'saturn.org.devmiyax.yabasanshioro2'))
WHERE shortname = 'saturn' AND NOT EXISTS (SELECT 1 FROM json_each(COALESCE(NULLIF(PlatformEntity.player_id_list, ''), '[]')) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'saturn.org.devmiyax.yabasanshioro2'));
COMMIT;
