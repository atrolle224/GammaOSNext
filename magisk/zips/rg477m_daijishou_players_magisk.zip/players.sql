BEGIN;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'dreamcast.rg477m.flycast', player, 'dreamcast - Flycast 477M', 'Flycast 477M (com.flycast.emulator.rg477m): both controllers as player 1, Vulkan.', replace(am_start_arguments, '-n com.flycast.emulator/', '-n com.flycast.emulator.rg477m/'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.com.flycast.emulator')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast')
WHERE shortname = 'dreamcast' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'dreamcast.rg477m.flycast') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'psp.rg477m.ppsspp', player, 'psp - PPSSPP 477M', 'PPSSPP 477M (org.ppsspp.ppsspp.rg477m): 3x rendering on the 477M.', replace(am_start_arguments, '-n org.ppsspp.ppsspp/.PpssppActivity', '-n org.ppsspp.ppsspp.rg477m/org.ppsspp.ppsspp.PpssppActivity'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.org.ppsspp.ppsspp')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp')
WHERE shortname = 'psp' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psp.rg477m.ppsspp') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'n64.rg477m.m64plusfz', player, 'n64 - M64Plus FZ 477M', 'M64Plus FZ 477M (org.mupen64plusae.v3.fzurita.rg477m).', replace(am_start_arguments, '-n org.mupen64plusae.v3.fzurita/', '-n org.mupen64plusae.v3.fzurita.rg477m/'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.org.mupen64plusae.v3.fzurita')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz')
WHERE shortname = 'n64' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'n64.rg477m.m64plusfz') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'nds.rg477m.melonds', player, 'nds - melonDS 477M', 'melonDS 477M (me.magnum.melonds.rg477m): OpenGL 2x, sticks on every controller.', replace(replace(am_start_arguments, 'me.magnum.melonds.LAUNCH_ROM', 'me.magnum.melonds.rg477m.LAUNCH_ROM'), 'me.magnum.melonds/.ui', 'me.magnum.melonds.rg477m/me.magnum.melonds.ui'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.me.magnum.melonds')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds')
WHERE shortname = 'nds' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'nds.rg477m.melonds') IS NOT NULL;
INSERT INTO PlayerEntity (unique_id, player, name, description, am_start_arguments, kill_package_processes, kill_package_processes_warning, accepted_filename_regex, extra)
SELECT 'psx.rg477m.swanstation', player, 'psx - SwanStation 477M', 'RetroArch 477M with SwanStation, tuned for the 477M (4x = the panel''s 1280x960, Vulkan).', replace(am_start_arguments, 'com.retroarch.aarch64', 'com.retroarch.rg477m'), 1, 0, accepted_filename_regex, extra
FROM PlayerEntity WHERE id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.ra64.swanstation')
AND NOT EXISTS (SELECT 1 FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation');
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation')
WHERE shortname = 'psx' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'psx.rg477m.swanstation') IS NOT NULL;
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m')
WHERE shortname = 'gc' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'gc.org.dolphinemu.dolphinemu.rg477m') IS NOT NULL;
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod')
WHERE shortname = 'ps2' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'ps2.com.armsx2.dnsmod') IS NOT NULL;
UPDATE PlatformEntity SET
 player_id_list = CASE WHEN EXISTS (SELECT 1 FROM json_each(PlatformEntity.player_id_list) WHERE value = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug'))
   THEN player_id_list
   ELSE json_insert(player_id_list, '$[#]', (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug')) END,
 default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug')
WHERE shortname = 'xbox' AND is_visible = 1 AND (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'xbox.com.rfandango.haku_x.debug') IS NOT NULL;
COMMIT;
