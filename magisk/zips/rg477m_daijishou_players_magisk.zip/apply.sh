#!/system/bin/sh
# Daijishou: the RG477M builds as players, each the default of its visible platform
# (Dreamcast Flycast 477M, PSP PPSSPP 477M, N64 M64Plus FZ 477M, DS melonDS 477M,
# PS1 SwanStation 477M, GameCube Dolphin 477M, PS2 ARMSX2 DNS, Xbox hakuX Mali,
# GB/GBC/GBA, SNES, Sega CD/Genesis/Master System/Game Gear and NGPC on RetroArch 477M),
# and SwanStation's RetroArch options set for the 477M. Backed up first; safe to run again.
MOD=${0%/*}
PKG=com.magneticchen.daijishou
DB=/data/data/$PKG/databases/Daijishou.db
SQ=$MOD/sqlite3
chmod 755 "$SQ"
[ -f "$DB" ] || { echo "Daijishou's database wasn't found."; exit 0; }
am force-stop $PKG 2>/dev/null
sleep 1
OWNER=$(stat -c %u /data/data/$PKG)
CTX=$(/system/bin/ls -Z "$DB" | awk '{print $1}')
BK=/data/adb/rg477m/daijishou-backup-$(date +%Y%m%d-%H%M%S)
mkdir -p "$BK" && cp "$DB"* "$BK"/
echo "backup: $BK"
if "$SQ" "$DB" < "$MOD/players.sql"; then
  "$SQ" -separator ': ' "$DB" "select p.name, e.name from PlatformEntity p join PlayerEntity e on e.id = p.default_player_id where p.is_visible = 1 and p.shortname in ('dreamcast','psp','n64','nds','psx','gc','ps2','xbox','saturn','gb','gbc','gba','snes','segacd','genesis','master','gamegear','ngpc')"
  for y in org.devmiyax.yabasanshioro2.pro org.devmiyax.yabasanshioro2; do
    pm list packages "$y" 2>/dev/null | grep -qx "package:$y" || continue
    "$SQ" "$DB" "UPDATE PlatformEntity SET default_player_id = (SELECT MIN(id) FROM PlayerEntity WHERE unique_id = 'saturn.$y') WHERE shortname = 'saturn'"
    break
  done
  echo "done"
else
  cp "$BK"/* /data/data/$PKG/databases/
  echo "couldn't change the database: the backup was put back"
fi
for f in "$DB" "$DB-wal" "$DB-shm" "$DB-journal"; do
  [ -e "$f" ] || continue
  chown $OWNER:$OWNER "$f"; chmod 660 "$f"; chcon "$CTX" "$f" 2>/dev/null
done

# SwanStation 477M: Vulkan at 4x (the PS1's 320x240 becomes the panel's 1280x960), true colour
CFGF=/data/media/0/Android/data/com.retroarch.rg477m/files/retroarch.cfg
CD=$(grep '^rgui_config_directory = ' "$CFGF" 2>/dev/null | cut -d'"' -f2 | sed 's#^/storage/emulated/0#/data/media/0#')
[ -n "$CD" ] || CD=/data/media/0/RetroArch/config
O=$CD/SwanStation/SwanStation.opt
mkdir -p "$CD/SwanStation"
[ -f "$O" ] && [ ! -f "$O.before-477m" ] && cp "$O" "$O.before-477m"
touch "$O"
for kv in GPU_Renderer=Vulkan GPU_ResolutionScale=4 GPU_TrueColor=true GPU_PGXPEnable=true GPU_UseThread=true; do
  k=swanstation_${kv%%=*}; v=${kv#*=}
  if grep -q "^$k = " "$O"; then sed -i "s#^$k = .*#$k = \"$v\"#" "$O"; else echo "$k = \"$v\"" >> "$O"; fi
done
chown $(stat -c %u:%g "$CD") "$CD/SwanStation" "$O"* 2>/dev/null
chcon $(/system/bin/ls -Zd "$CD" | awk '{print $1}') "$CD/SwanStation" "$O"* 2>/dev/null
echo "SwanStation 477M options: Vulkan, 4x, true colour ($O)"

# Flycast 477M is a new app: give it the Dreamcast BIOS RetroArch already has
FD=/data/media/0/Android/data/com.flycast.emulator.rg477m/files/data
SRC=/data/media/0/RetroArch/system/dc
if [ -d "${FD%/data}" ] && [ -f "$SRC/dc_boot.bin" ]; then
  mkdir -p "$FD"
  for b in dc_boot.bin dc_flash.bin; do
    [ -f "$SRC/$b" ] && [ ! -f "$FD/$b" ] && cp "$SRC/$b" "$FD/$b"
  done
  chown -R $(stat -c %u:%g "${FD%/data}") "$FD"; chcon -R $(/system/bin/ls -Zd "${FD%/data}" | awk '{print $1}') "$FD" 2>/dev/null
  echo "Flycast 477M: Dreamcast BIOS copied from RetroArch"
fi

sh "$MOD/ra477m.sh"
