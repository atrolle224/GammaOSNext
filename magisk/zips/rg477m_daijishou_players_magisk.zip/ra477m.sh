#!/system/bin/sh
# RetroArch 477M: RetroAchievements on, a controller profile for every gamepad
# (so no "not configured, using fallback"), and the default cores of the systems
# Daijishou now launches with it.
RA=com.retroarch.rg477m
S=/data/media/0
CFGF=$S/Android/data/$RA/files/retroarch.cfg
DATA=/data/data/$RA
BB=/data/adb/magisk/busybox
[ -d "$DATA" ] || { echo "RetroArch 477M isn't installed: skipped its setup."; exit 0; }
am force-stop $RA 2>/dev/null

cfg_get() { grep "^$2 = " "$1" 2>/dev/null | head -1 | cut -d'"' -f2; }
cfg_set() {
  if grep -q "^$2 = " "$1"; then sed -i "s#^$2 = .*#$2 = \"$3\"#" "$1"; else echo "$2 = \"$3\"" >> "$1"; fi
}
own_like() {   # give $2.. the owner and SELinux label of $1
  ref=$1; shift
  chown -R $(stat -c %u:%g "$ref") "$@" 2>/dev/null
  chcon -R $(/system/bin/ls -Zd "$ref" | awk '{print $1}') "$@" 2>/dev/null
}
sd() { echo "$1" | sed 's#^/storage/emulated/0#/data/media/0#'; }

# RetroAchievements
if [ -f "$CFGF" ]; then
  [ -f "$CFGF.before-477m-ra" ] || cp "$CFGF" "$CFGF.before-477m-ra"
  cfg_set "$CFGF" cheevos_enable true
  cfg_set "$CFGF" input_autodetect_enable true
  if [ -n "$(cfg_get "$CFGF" cheevos_token)" ]; then
    echo "RetroAchievements: on, signed in as $(cfg_get "$CFGF" cheevos_username)"
  else
    echo "RetroAchievements: on, but not signed in yet. Sign in once in RetroArch 477M,"
    echo "  or in any emulator and run the RA one sign-in module's Action button."
  fi
else
  echo "RetroArch 477M has no retroarch.cfg yet: open it once, then run this again."
fi

# controller profiles
AD=$(sd "$(cfg_get "$CFGF" joypad_autoconfig_dir)")
[ -n "$AD" ] && [ "$AD" != default ] || AD=$DATA/autoconfig
mkdir -p "$AD/android"

profile() {   # name vid pid hat(1/0)
  f=$AD/android/RG477M_$(printf '%s' "$1" | tr -c 'A-Za-z0-9._-' '_').cfg
  {
    echo 'input_driver = "android"'
    echo "input_device = \"$1\""
    [ -n "$2" ] && echo "input_vendor_id = \"$2\"" && echo "input_product_id = \"$3\""
    if [ "$4" = 1 ]; then
      echo 'input_up_btn = "h0up"'; echo 'input_down_btn = "h0down"'
      echo 'input_left_btn = "h0left"'; echo 'input_right_btn = "h0right"'
    else
      echo 'input_up_btn = "19"'; echo 'input_down_btn = "20"'
      echo 'input_left_btn = "21"'; echo 'input_right_btn = "22"'
    fi
    cat <<'EOF'
input_a_btn = "97"
input_b_btn = "96"
input_x_btn = "100"
input_y_btn = "99"
input_l_btn = "102"
input_r_btn = "103"
input_l2_btn = "104"
input_r2_btn = "105"
input_l2_axis = "+8"
input_r2_axis = "+9"
input_l3_btn = "106"
input_r3_btn = "107"
input_start_btn = "108"
input_select_btn = "109"
input_menu_toggle_btn = "110"
input_l_x_plus_axis = "+0"
input_l_x_minus_axis = "-0"
input_l_y_plus_axis = "+1"
input_l_y_minus_axis = "-1"
input_r_x_plus_axis = "+2"
input_r_x_minus_axis = "-2"
input_r_y_plus_axis = "+3"
input_r_y_minus_axis = "-3"
EOF
  } > "$f"
  echo "  controller profile: $1"
}

echo "Controller profiles in $AD/android:"
# the 8BitDo SN30 Pro for Xbox (and Xbox pads) by name, connected or not
profile "Xbox Wireless Controller" "" "" 1
# every gamepad connected now, the 477M's own controls included
awk '
  /^N: Name=/ { n = substr($0, 10); sub(/"$/, "", n) }
  /^I: / { for (i = 2; i <= NF; i++) { split($i, kv, "="); if (kv[1] == "Vendor") v = kv[2]; if (kv[1] == "Product") p = kv[2] } }
  /^B: KEY=/ { key = substr($0, 8) }
  /^B: ABS=/ { abs = substr($0, 8) }
  /^$/ {
    k = split(key, w, " "); pad = 0
    if (k >= 5) { x = w[k - 4]; while (length(x) < 16) x = "0" x; pad = index("13579bdf", substr(x, 4, 1)) > 0 }
    a = split(abs, aw, " "); hat = 0
    if (a >= 1) { y = aw[a]; while (length(y) < 16) y = "0" y; hat = index("13579bdf", substr(y, 12, 1)) > 0 }
    if (pad && n != "Xbox Wireless Controller") print n "|" v "|" p "|" hat
    n = v = p = key = abs = ""
  }' /proc/bus/input/devices | sort -u > "$DATA/.rg477m_pads"
while IFS='|' read -r n v p h; do
  [ -n "$n" ] && profile "$n" "${v:+$((0x$v))}" "${p:+$((0x$p))}" "$h"
done < "$DATA/.rg477m_pads"
rm -f "$DATA/.rg477m_pads"
own_like "$DATA" "$AD"
case "$AD" in $S/*) own_like "$S/Android/data/$RA" "$AD" ;; esac

# cores the new players start with
CD=$(sd "$(cfg_get "$CFGF" libretro_directory)")
[ -n "$CD" ] && [ "$CD" != default ] || CD=$DATA/cores
mkdir -p "$CD"
URL=https://buildbot.libretro.com/nightly/android/latest/arm64-v8a
got=""; miss=""
for c in gambatte mgba snes9x genesis_plus_gx mednafen_ngp; do
  so=${c}_libretro_android.so
  [ -f "$CD/$so" ] && continue
  if $BB wget -q -T 30 -O "$CD/$so.zip" "$URL/$so.zip" 2>/dev/null && $BB unzip -o -q "$CD/$so.zip" -d "$CD"; then
    got="$got $c"
  else
    miss="$miss $c"
  fi
  rm -f "$CD/$so.zip"
done
own_like "$DATA" "$CD"
chmod 644 "$CD"/*.so 2>/dev/null
[ -n "$got" ] && echo "Cores downloaded:$got"
[ -n "$miss" ] && echo "Cores still missing (no internet?):$miss. Get them in RetroArch 477M: Main Menu > Online Updater > Core Downloader."

# Snapdragon Game Super Resolution as a RetroArch shader (Shaders > Load > edge-smoothing/sgsr)
SD=$(sd "$(cfg_get "$CFGF" video_shader_dir)")
[ -n "$SD" ] && [ "$SD" != default ] || SD=$DATA/shaders
if [ -d "$SD/shaders_slang" ]; then SG=$SD/shaders_slang/edge-smoothing/sgsr; else SG=$SD/edge-smoothing/sgsr; fi
mkdir -p "$SG" && cp -r "${0%/*}/sgsr/." "$SG/"
case "$SD" in $S/*) own_like "$S/Android/data/$RA" "$SD" ;; *) own_like "$DATA" "$SD" ;; esac
echo "GSR upscaler: Quick Menu > Shaders > Load > ${SG#$SD/}/sgsr.slangp"

# Sega CD needs a BIOS for genesis_plus_gx
SYS=$(sd "$(cfg_get "$CFGF" system_directory)")
[ -n "$SYS" ] && [ "$SYS" != default ] || SYS=$S/RetroArch/system
for b in bios_CD_U.bin bios_CD_E.bin bios_CD_J.bin; do [ -f "$SYS/$b" ] && cdb=1; done
[ -n "$cdb" ] || echo "Sega CD: no BIOS found (bios_CD_U.bin, bios_CD_E.bin or bios_CD_J.bin in $SYS)."
exit 0
